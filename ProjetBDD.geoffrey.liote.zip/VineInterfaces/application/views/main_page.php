<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Tutorial Sample Page</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

</head>
<body>



<nav class="navbar navbar-expand-lg navbar-light" style="background-color: #4e285b;">
<img src="https://image.flaticon.com/icons/svg/168/168570.svg" width="30" height="30" class="d-inline-block align-top" alt="">
  <a class="navbar-brand" href="#" style="color:white">Wine Map</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo site_url(); ?>/Welcome/mapPage" style="color:white">Map <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url(); ?>/Welcome/graphPage" style="color:white">Graph<span class="sr-only"></span></a>
      </li>
    </ul>

  </div>
</nav>

<header class="page-header header container-fluid" style="background-image: url('https://pixelz.cc/wp-content/uploads/2018/10/wine-barrels-and-grapes-uhd-4k-wallpaper.jpg');  background-size: cover;
  background-position: center;
  position: relative;">


  <div class="overlay">

  <div class="description">
  <h1>Welcome to the Wine Map!</h1>
  <p>Search wine's plots !</p>
  
</div>
  </div>
</header>

<footer class="page-footer">
  <div class="container">
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-12">
      <h6 class="text-uppercase font-weight-bold">Additional Information</h6>
      <p>Dévelopeurs : Gaétan Bonin, Raphaël Delcroix, Mathis Espanel, Geoffrey Lioté</p>
      <p>Réseaux : Loïc Populier, Quentin Pedretti, Eric Schalk</p>
    </div>
    <div class="col-lg-4 col-md-4 col-sm-12">
      <h6 class="text-uppercase font-weight-bold">Contact</h6>
      <p>1640 Riverside Drive, Hill Valley, California
      <br/>info@mywebsite.com
      <br/>+ 01 234 567 88
      <br/>+ 01 234 567 89</p>
    </div>
  </div>
  <div class="footer-copyright text-center">© 2019 Copyright: Diiage</div>
</footer>

<style>
  .overlay {
  position: absolute;
  min-height: 100%;
  min-width: 100%;
  left: 0;
  top: 0;
  background: rgba(0, 0, 0, 0.6);
  }
  .description{
  left: 50%;
  position: absolute;
  top: 45%;
  transform: translate(-50%, -55%);
  text-align: center;
}
.description h1 {
  color: #E4A73B;
}
.description p {
  color: #fff;
  font-size: 1.3rem;
  line-height: 1.5;
}

.description button {
  border:1px solid #E4A73B;
  background:#E4A73B;
  border-radius: 0;
  color:#fff;
}
.description button:hover {
  border:1px solid #fff;
  background:#fff;
  color:#000;
}
.page-footer {
  background-color: #222;
  color: #ccc;
  padding: 60px 0 30px;
}
.footer-copyright {
  color: #666;
  padding: 40px 0;


}

@media (max-width: 575.98px) {
  .description {
    left: 0;
    padding: 0 15px;
    position: absolute;
    top: 10%;
    transform: none;
    text-align: center;
  }
  
  .description h1 {
    font-size: 2em;
  }
  
  .description p {
    font-size: 1.2rem;
  }
  
  .features {
    margin: 0;
  }
}

  </style>
<script src="https://code.jquery.com/jquery-3.4.1.js" integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU=" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>

<script>
$(document).ready(function(){
  $('.header').height($(window).height());
})
</script>
</body>
</html>