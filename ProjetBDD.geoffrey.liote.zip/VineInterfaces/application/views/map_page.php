
<!DOCTYPE html>
<html>
<head>
<meta charset='utf-8' />
<title>Display a map</title>
 <!-- Required meta tags -->
<meta name='viewport' content='initial-scale=1,maximum-scale=1,user-scalable=no' />
<script src='https://api.tiles.mapbox.com/mapbox-gl-js/v1.4.0/mapbox-gl.js'></script>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script src='https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-geocoder/v4.4.2/mapbox-gl-geocoder.min.js'></script>
<link rel='stylesheet' href='https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-geocoder/v4.4.2/mapbox-gl-geocoder.css' type='text/css' />
<!-- Promise polyfill script required to use Mapbox GL Geocoder in IE 11 -->
<script src="https://cdn.jsdelivr.net/npm/es6-promise@4/dist/es6-promise.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/es6-promise@4/dist/es6-promise.auto.min.js"></script>    
<link href='https://api.tiles.mapbox.com/mapbox-gl-js/v1.4.0/mapbox-gl.css' rel='stylesheet' />
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<script
			  src="https://code.jquery.com/jquery-3.4.1.js"
			  integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
			  crossorigin="anonymous"></script>
<style>
  
body { margin:0; padding:0; }
#map { position:absolute; top:0; bottom:0; width:100%; }

#menu {
position: absolute;
background: #4E285B;
padding: 10px;
font-family: 'Open Sans', sans-serif;
color:white;
}
</style>
</head>


<div id='map'></div>


<script>
mapboxgl.accessToken = 'pk.eyJ1IjoiZ2VvZmZyZXlsaW90ZSIsImEiOiJjazFpeWF6dmMwNThlM2hzM2IybDR5OWdkIn0.tMdm2YAkIli_mbmbnBYi4A';
var map = new mapboxgl.Map({
container: 'map', // container id
style: 'mapbox://styles/mapbox/streets-v11', // stylesheet location
center: [5.05,47.32], // starting position [lng, lat]
zoom: 11 // starting zoom
});

map.addControl(new MapboxGeocoder({
accessToken: mapboxgl.accessToken,
mapboxgl: mapboxgl
}));

map.on('load', function() {
map.setPaintProperty('building', 'fill-color', [
"interpolate",
["exponential", 0.5],
["zoom"],
15,
"#e2714b",
22,
"#eee695"
]);
 
map.setPaintProperty('building', 'fill-opacity', [
"interpolate",
["exponential", 0.5],
["zoom"],
15,
0,
22,
1
]);

// When a click event occurs on a feature in the states layer, open a popup at the
// location of the click, with description HTML from its properties.
map.on('click', 'polygons', function (e) {
    var popup = new mapboxgl.Popup()
        .setLngLat(e.lngLat)
        .setHTML(e.features[0].properties.appellation)
        .addTo(map);
});
 
// Change the cursor to a pointer when the mouse is over the states layer.
map.on('mouseenter', 'polygons', function () {
map.getCanvas().style.cursor = 'pointer';
});
 
// Change it back to a pointer when it leaves.
map.on('mouseleave', 'polygons', function () {
map.getCanvas().style.cursor = '';
});

});

</script>

<body>
 

<nav class="navbar navbar-expand-lg navbar-light" style="background-color: #4e285b;">
<img src="https://image.flaticon.com/icons/svg/168/168570.svg" width="30" height="30" class="d-inline-block align-top" alt="">
  <a class="navbar-brand" href="<?php echo site_url(); ?>/Welcome/index" style="color:white">Wine Map</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="#" style="color:white">Map <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url(); ?>/Welcome/graphPage" style="color:white">Graph<span class="sr-only"></span></a>
      </li>
    </ul>

  </div>
</nav>

<div id='menu'>
  <div>
  <input id='streets-v11' type='radio' name='rtoggle' value='streets' checked='checked'>
  <label for='streets'>streets</label>
  <input id='satellite-v9' type='radio' name='rtoggle' value='satellite'>
  <label for='satellite'>satellite</label>
  </div>
  <input type="text" id="searchAocByCommune" name="searchAocByCommune">
</div>


<script>
var polygonsLayer = "polygons";
  var layerList = document.getElementById('menu');
var inputs = layerList.getElementsByTagName('input');
 
function switchLayer(layer) {
var layerId = layer.target.id;
map.setStyle('mapbox://styles/mapbox/' + layerId);
}
 
for (var i = 0; i < inputs.length; i++) {
inputs[i].onclick = switchLayer;
}

$("#searchAocByCommune").keyup(searchAocByCommune);

function searchAocByCommune(){
  commune = $("#searchAocByCommune").val();
  $.getJSON('<?php echo site_url(); ?>/ApiController/searchAocByCommune?commune='+commune, displayAoc);
}

function displayAoc(json){
  if(json.length > 0){

  polygons = [];
  for(var i=0; i< json.length; i++ ){
    properties = {'appellation' : json[i].denomination }
    console.log(json[i].denomination);
    polygons.push({'type': 'Feature', 'properties' : properties, 'geometry': JSON.parse(json[i].geom)})
  }
  
  layer = {
 'id': polygonsLayer,
 'type': 'fill',
 'source': {
 'type': 'geojson',
 'data': {
  "type": "FeatureCollection",
  "features": polygons
 }
 },
 'layout': {},
 'paint': {
 'fill-color': '#900',
 'fill-opacity': 0.5
 }
 }; 
 if(typeof map.getLayer(polygonsLayer) !== 'undefined') {
      // Remove map layer & source.
      map.removeLayer(polygonsLayer).removeSource(polygonsLayer);
    }
  map.addLayer(layer);
  map.setStyle('mapbox://styles/mapbox/' + polygonsLayer);
  map.flyTo({center: JSON.parse(json[0].geom).coordinates[0][0][0]});
}
}


  </script>
</body>
</html>