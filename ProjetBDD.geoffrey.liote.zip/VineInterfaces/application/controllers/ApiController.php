<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ApiController extends CI_Controller {
	public function searchAocByCommune()
	{
		$commune = $this->input->get("commune");
		$this->load->model("ApiModel");
		$data = $this->ApiModel->getAocByCommune($commune);
		echo json_encode($data);
	}

}
