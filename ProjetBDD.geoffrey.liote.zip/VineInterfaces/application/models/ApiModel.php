<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ApiModel extends CI_Model {
	
	public function getAocByCommune($commune)
	{
		$this->load->database();
		$query = $this->db->query("select appellation.denomination, ST_AsGeoJSON(zone_appellation.geom) as geom from zone_appellation inner join commune on commune.id = zone_appellation.insee inner join appellation on appellation.id = zone_appellation.id_appellation where lower(commune.nom) = lower('$commune')");
		return $query->result();

	}

}
